package com.casestudy.config;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.test.MetaDataInstanceFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.casestudy.model.Employee;

@RunWith(SpringJUnit4ClassRunner.class)
@EnableBatchProcessing
@ContextConfiguration(classes= {TestDatabaseConfiguration.class, BatchConfig.class})
public class StepTest {

    @Test
    public void testReader() throws Exception {
    	FlatFileItemReader<Employee> itemReader = new FlatFileItemReader<>();
        itemReader.setLineMapper(lineMapper());
        itemReader.setLinesToSkip(1);
        itemReader.setResource(new FileSystemResource("src/test/resources/input/inputData.csv"));
    	itemReader.open(MetaDataInstanceFactory.createStepExecution().getExecutionContext());
    	Employee emp = new Employee();
    	emp.setId("1");
    	emp.setFirstName("Lokesh");
    	emp.setLastName("Gupta");
		Employee expectedEmployee = itemReader.read();
        Assert.assertEquals(emp.getId(), expectedEmployee.getId());
        Assert.assertEquals(emp.getFirstName(), expectedEmployee.getFirstName());
        Assert.assertEquals(emp.getLastName(), expectedEmployee.getLastName());
    }
    public LineMapper<Employee> lineMapper() {
        DefaultLineMapper<Employee> lineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setNames("id", "firstName", "lastName" );
        lineTokenizer.setIncludedFields(0, 1, 2 );
        BeanWrapperFieldSetMapper<Employee> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(Employee.class);
        lineMapper.setLineTokenizer(lineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);
        return lineMapper;
    }
}
