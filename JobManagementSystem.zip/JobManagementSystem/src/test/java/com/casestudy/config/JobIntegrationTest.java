package com.casestudy.config;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@EnableBatchProcessing
@ContextConfiguration(classes= {BatchConfig.class, TestJobConfiguration.class})
public class JobIntegrationTest {

	@Autowired
	JobLauncherTestUtils jobLauncherTestUtils;

	@Autowired
	DataSource dataSource;


	@Before
	public void setUp() throws SQLException {
		try(Connection connection = dataSource.getConnection()){
			try(Statement s = connection.createStatement()){

				s.execute("CREATE TABLE EMPLOYEE  (\n" + 
						"    ID VARCHAR(10),  \n" + 
						"    FIRST_NAME VARCHAR(100),  \n" + 
						"    LAST_NAME VARCHAR(100) \n" + 
						")");}
		}

	}

	@After
	public void tearDown() throws SQLException{
		try(Connection connection = dataSource.getConnection()){
			try(Statement s = connection.createStatement()){
				try(ResultSet rs = s.executeQuery("select * from EMPLOYEE where id = 1")){
					while(rs.next()) {
						Assert.assertEquals(1, rs.getInt(1));
						Assert.assertEquals("Lokesh", rs.getString(2));
						Assert.assertEquals("Gupta", rs.getString(3));
					}
				}
			}
		}


	}

	@Test
	public void testJob() throws Exception {
		JobExecution jobExecution = jobLauncherTestUtils.launchJob();
		Assert.assertNotNull(jobExecution);
		Assert.assertEquals(jobExecution.getExitStatus(), ExitStatus.COMPLETED);
	}


}
