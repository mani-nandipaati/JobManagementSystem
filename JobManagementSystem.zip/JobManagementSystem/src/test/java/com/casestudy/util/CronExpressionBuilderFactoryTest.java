package com.casestudy.util;

import org.junit.Assert;
import org.junit.Test;

import com.casestudy.schedule.Month;
import com.casestudy.schedule.RecurringType;
import com.casestudy.schedule.ScheduleDetail;
import com.casestudy.schedule.ScheduleType;
import com.casestudy.schedule.Week;
import com.casestudy.schedule.WeekDay;

public class CronExpressionBuilderFactoryTest {

	
	CronExpressionBuilderFactory cronExpressionBuilderFactory = CronExpressionBuilderFactory.getInstance();
	
	@Test
	public void testIntradayMinutesScheduleCronExpression() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.INTRADAY);
		scheduleDetail.setRecurringInterval(2);
		scheduleDetail.setRecurringType(RecurringType.MINUTES);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 0/2 * 1/1 * ? *", cronExpression);
	}
	
	@Test
	public void testIntradayHourlyScheduleCronExpression() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.INTRADAY);
		scheduleDetail.setRecurringInterval(2);
		scheduleDetail.setRecurringType(RecurringType.HOURLY);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 0 0/2 1/1 * ? *", cronExpression);
	}
	
	@Test
	public void testIntradayHourlyScheduleCronExpressionWithSpecificRunTime() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.INTRADAY);
		scheduleDetail.setRecurringType(RecurringType.HOURLY);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 1/1 * ? *", cronExpression);
	}
	
	@Test
	public void testDailyScheduleCronExpressionForOnlyWeekDays() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.DAILY);
		scheduleDetail.setisWeekDay(true);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 ? * MON-FRI *", cronExpression);
	}
	
	@Test
	public void testDailyScheduleCronExpressionForRecurringDays() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.DAILY);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		scheduleDetail.setRecurringDays(3);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 1/3 * ? *", cronExpression);
	}
	
	@Test
	public void testWeeklyScheduleCronExpression() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.WEEKLY);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		scheduleDetail.setWeekDays(new String[] {"MON","FRI"});
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 ? * MON,FRI *", cronExpression);
	}
	
	@Test
	public void testMonthlyScheduleCronExpressionForRecurringDAyOfMonth() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.MONTHLY);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		scheduleDetail.setDayOfMonth(6);
		scheduleDetail.setRecurringMonthOfYear(3);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 6 1/3 ? *", cronExpression);
	}
	
	@Test
	public void testMonthlyScheduleCronExpressionForRecurringWeekOfMonth() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.MONTHLY);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		scheduleDetail.setWeekOfMonth(Week.SECOND);
		scheduleDetail.setWeekDay(WeekDay.FRI);
		scheduleDetail.setRecurringMonthOfYear(3);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 ? 1/3 FRI#2 *", cronExpression);
	}
	
	@Test
	public void testMonthlyScheduleCronExpressionForSpecificDayAndMonthOfYear() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.YEARLY);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		scheduleDetail.setDayOfMonth(6);
		scheduleDetail.setMonthOfYear(Month.DEC);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 6  12 ? *", cronExpression);
	}
	
	@Test
	public void testMonthlyScheduleCronExpressionForSpecificWeekOfMonthAndWeekDay() {
		ScheduleDetail scheduleDetail = new ScheduleDetail();
		scheduleDetail.setScheduleType(ScheduleType.YEARLY);
		scheduleDetail.setRunHour(12);
		scheduleDetail.setRunMinute(15);
		scheduleDetail.setWeekOfMonth(Week.SECOND);
		scheduleDetail.setMonthOfYear(Month.DEC);
		scheduleDetail.setWeekDay(WeekDay.THU);
		ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(scheduleDetail.getScheduleType());
		String cronExpression = cronBuilder.getExpression(scheduleDetail);
		Assert.assertEquals("0 15 12 ? 12 THU#2 *", cronExpression);
	}
	
}
