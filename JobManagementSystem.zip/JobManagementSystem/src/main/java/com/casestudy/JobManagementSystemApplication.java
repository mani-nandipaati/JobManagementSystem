package com.casestudy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.casestudy.service.JobService;

@SpringBootApplication
public class JobManagementSystemApplication {

	private static Logger logger = LoggerFactory.getLogger(JobManagementSystemApplication.class);
	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(JobManagementSystemApplication.class, args);
		boolean jobsLoaded = applicationContext.getBean(JobService.class).createJob(null);
		logger.info("External Jobs loaded {}", jobsLoaded);
		
	}

}
