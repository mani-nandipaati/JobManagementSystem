package com.casestudy.schedule;

public enum Week {
	FIRST, SECOND, THRID, FOURTH
}
