package com.casestudy.schedule;

public enum ScheduleType {
	REALTIME, INTRADAY, DAILY, MONTHLY, WEEKLY, YEARLY;
}
