package com.casestudy.schedule;

import org.apache.commons.lang.builder.ToStringBuilder;

/** Contains trigger information to schedule job
 * @author nandipati
 *
 */
public class TriggerDetails {
	private String triggerName;
	private String triggerGroup;
	private int priority;
	public String getTriggerName() {
		return triggerName;
	}
	public void setTriggerName(String triggerName) {
		this.triggerName = triggerName;
	}
	public String getTriggerGroup() {
		return triggerGroup;
	}
	public void setTriggerGroup(String triggerGroup) {
		this.triggerGroup = triggerGroup;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
