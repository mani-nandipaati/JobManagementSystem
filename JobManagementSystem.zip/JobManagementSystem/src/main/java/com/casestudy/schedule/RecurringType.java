package com.casestudy.schedule;

public enum RecurringType {
	HOURLY, MINUTES;
}
