package com.casestudy.schedule;

import org.apache.commons.lang.builder.ToStringBuilder;

/** Base class to provide job information 
 * to create external jobs
 * @author Mani
 *
 */
public class CustomJobDetails {

	private String jobName;
	private String jobGroup;
	private String stepName;
	private TriggerDetails triggerDetails;
	private Task task;
	private ScheduleDetail scheduleDetail;
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobGroup() {
		return jobGroup;
	}
	public void setJobGroup(String jobGroup) {
		this.jobGroup = jobGroup;
	}
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public TriggerDetails getTriggerDetails() {
		return triggerDetails;
	}
	public void setTriggerDetails(TriggerDetails triggerDetails) {
		this.triggerDetails = triggerDetails;
	}
	public Task getTask() {
		return task;
	}
	public void setTask(Task task) {
		this.task = task;
	}
	public ScheduleDetail getScheduleDetail() {
		return scheduleDetail;
	}
	public void setScheduleDetail(ScheduleDetail scheduleDetail) {
		this.scheduleDetail = scheduleDetail;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
