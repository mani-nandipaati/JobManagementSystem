package com.casestudy.schedule;

import org.apache.commons.lang.builder.ToStringBuilder;

/** Contain external task information
 * @author Mani
 *
 */
public class Task {
	private String taskClassName;
	private String taskMethod;
	public String getTaskClassName() {
		return taskClassName;
	}
	public void setTaskClassName(String taskClassName) {
		this.taskClassName = taskClassName;
	}
	public String getTaskMethod() {
		return taskMethod;
	}
	public void setTaskMethod(String taskMethod) {
		this.taskMethod = taskMethod;
	}
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
