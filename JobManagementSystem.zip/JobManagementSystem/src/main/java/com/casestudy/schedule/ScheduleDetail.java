package com.casestudy.schedule;

import org.apache.commons.lang.builder.ToStringBuilder;

/** Contains schedule related information for jobs
 * @author Mani
 *
 */
public class ScheduleDetail {
	
	private ScheduleType scheduleType;
	private int runMinute;
	private int runHour;
	private int recurringInterval;
	private RecurringType recurringType;
	/*Daily Options*/
	private int recurringDays;
	private boolean isWeekDay;
	private String[] weekDays;//for Weekly
	/*Monthly&Yearly options*/
	private int dayOfMonth;
	private int recurringMonthOfYear;//Only for Monthly
	private Week weekOfMonth;
	private WeekDay weekDay;
	/*Yearly Options*/
	private Month monthOfYear;
	public ScheduleType getScheduleType() {
		return scheduleType;
	}
	public void setScheduleType(ScheduleType scheduleType) {
		this.scheduleType = scheduleType;
	}
	public int getRunMinute() {
		return runMinute;
	}
	public void setRunMinute(int runMinute) {
		this.runMinute = runMinute;
	}
	public int getRunHour() {
		return runHour;
	}
	public void setRunHour(int runHour) {
		this.runHour = runHour;
	}
	public int getRecurringInterval() {
		return recurringInterval;
	}
	public void setRecurringInterval(int recurringInterval) {
		this.recurringInterval = recurringInterval;
	}
	public RecurringType getRecurringType() {
		return recurringType;
	}
	public void setRecurringType(RecurringType recurringType) {
		this.recurringType = recurringType;
	}
	public boolean isWeekDay() {
		return isWeekDay;
	}
	public void setisWeekDay(boolean isWeekDay) {
		this.isWeekDay = isWeekDay;
	}
	public String[] getWeekDays() {
		return weekDays;
	}
	public void setWeekDays(String[] weekDays) {
		this.weekDays = weekDays;
	}
	public int getDayOfMonth() {
		return dayOfMonth;
	}
	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}
	public int getRecurringMonthOfYear() {
		return recurringMonthOfYear;
	}
	public void setRecurringMonthOfYear(int recurringMonthOfYear) {
		this.recurringMonthOfYear = recurringMonthOfYear;
	}
	
	public Week getWeekOfMonth() {
		return weekOfMonth;
	}
	public void setWeekOfMonth(Week weekOfMonth) {
		this.weekOfMonth = weekOfMonth;
	}
	public WeekDay getWeekDay() {
		return weekDay;
	}
	public void setWeekDay(WeekDay weekDay) {
		this.weekDay = weekDay;
	}
	public Month getMonthOfYear() {
		return monthOfYear;
	}
	public void setMonthOfYear(Month monthOfYear) {
		this.monthOfYear = monthOfYear;
	}
	public int getRecurringDays() {
		return recurringDays;
	}
	public void setRecurringDays(int recurringDays) {
		this.recurringDays = recurringDays;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
