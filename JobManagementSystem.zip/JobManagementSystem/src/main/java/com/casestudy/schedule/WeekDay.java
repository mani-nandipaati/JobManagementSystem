package com.casestudy.schedule;

public enum WeekDay {
	MON, TUE, WED, THU, FRI, SAT, SUN
}
