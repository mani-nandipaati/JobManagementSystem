package com.casestudy.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.StringUtils;

import com.casestudy.schedule.CustomJobDetails;
import com.casestudy.schedule.ScheduleType;
import com.casestudy.util.CronExpressionBuilderFactory;
import com.casestudy.util.ScheduleCronBuilder;
import com.casestudy.util.TaskCreater;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/** Responsible for all schedule related operations
 * @author Mani
 *
 */
@Service
public class JobService {

	Logger logger = LoggerFactory.getLogger(JobService.class);

	@Autowired
	private JobBuilderFactory jobs;

	@Autowired
	private StepBuilderFactory steps;

	@Autowired
	JobRegistry jobRegistry;

	@Autowired
	PlatformTransactionManager transactionManager;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	Scheduler scheduler;

	@Autowired
	JobLauncher jobLauncher;
	
	@Value("${job.path}")
	String jobPath;

	CronExpressionBuilderFactory cronExpressionBuilderFactory = CronExpressionBuilderFactory.getInstance();

	/** Creates/Schedules all jobs based on path
	 * @param path
	 * @return
	 */
	public boolean createJob(String path) {
		if (StringUtils.isEmpty(path)) {
			path = this.jobPath;
		}
		final List<String> jobFailures = new ArrayList<>();
		logger.info("Creating jobs from path {}", path);
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<List<CustomJobDetails>> typeReference = new TypeReference<List<CustomJobDetails>>(){};
		InputStream inputStream = TypeReference.class.getResourceAsStream(path);
		List<CustomJobDetails> customJobDetails = null;
		try {
			customJobDetails = mapper.readValue(inputStream,typeReference);
		}
		catch(Exception e) {
			logger.error("Failed reading values from input JSON {}",e);
			return false;
		}

		if(customJobDetails != null) {
			customJobDetails.forEach(customJobDetail -> {
				logger.info("Creating a schedule for job {}", customJobDetail);
				if(customJobDetail.getScheduleDetail().getScheduleType() == ScheduleType.REALTIME) {
					JobParameters params = new JobParametersBuilder()
							.addString("JobID", String.valueOf(System.currentTimeMillis()))
							.toJobParameters();
					Tasklet tasklet = TaskCreater.methodInvokingTaskletAdapter(customJobDetail.getTask().getTaskClassName(),customJobDetail.getTask().getTaskMethod());
					Step step = TaskCreater.createStep(steps, tasklet, customJobDetail.getStepName());
					Job job = TaskCreater.createJob(jobs, step,customJobDetail.getJobName() ,jobRegistry);
					try {
						jobLauncher.run(job, params);
						logger.info("Job completed succesfully");
					} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
							| JobParametersInvalidException e) {
						logger.error("Unable to run job due to error {}", e);
						jobFailures.add(customJobDetail.getJobName()+"~"+customJobDetail.getJobGroup());
					}

				}
				else {
					ScheduleCronBuilder cronBuilder = cronExpressionBuilderFactory.getCronBuilder(customJobDetail.getScheduleDetail().getScheduleType());
					String cronExpression = cronBuilder.getExpression(customJobDetail.getScheduleDetail());
					Tasklet tasklet = TaskCreater.methodInvokingTaskletAdapter(customJobDetail.getTask().getTaskClassName(),customJobDetail.getTask().getTaskMethod());
					Step step = TaskCreater.createStep(steps, tasklet, customJobDetail.getStepName());
					TaskCreater.createJob(jobs, step,customJobDetail.getJobName() ,jobRegistry);
					JobDetail jobDetail = TaskCreater.createJobDetail(customJobDetail.getJobName(), customJobDetail.getJobGroup());
					Trigger trigger = TaskCreater.createJobTrigger(jobDetail, customJobDetail.getTriggerDetails().getTriggerName(), 
							customJobDetail.getTriggerDetails().getTriggerGroup(), cronExpression, customJobDetail.getTriggerDetails().getPriority());
					try {
						TaskCreater.scheduleJobWithTriggerIfNotPresent(scheduler, jobDetail, trigger);
						logger.info("Job has been scheduled succesfully");
					} catch (SchedulerException e) {
							logger.error("Unable to Schedule job due to error {}", e);
							jobFailures.add(customJobDetail.getJobName()+"~"+customJobDetail.getJobGroup());
					}
				}
			} );
		} 
		jobFailures.forEach(jobFailure -> logger.info("Failed Job is {}", jobFailure));
		return jobFailures.isEmpty();

	}

	/**Pause schedule based on jobName, jobGroup
	 * or based on triggerName, triggerGroup
	 * @param jobName
	 * @param jobGroup
	 * @param triggerName
	 * @param triggerGroup
	 * @return
	 */
	public boolean pauseSchedule( String jobName,  String jobGroup,  String triggerName,  String triggerGroup) {
		if(!StringUtils.isEmpty(jobName) && !StringUtils.isEmpty(jobGroup)) {
			try {
				scheduler.pauseJob(new JobKey(jobName, jobGroup));
				logger.info("Job with jobName {} jobGroup {} paused succesfully", jobName, jobGroup);
				return true;
			} catch (SchedulerException e) {
				logger.error("Unable to pause job with jobName {} jobGroup {} due to error {}", jobName, jobGroup, e);
				return false;
			}	
		}
		if(!StringUtils.isEmpty(triggerName) && !StringUtils.isEmpty(triggerGroup)) {
			try {
				scheduler.pauseTrigger(new TriggerKey(triggerName, triggerGroup));
				logger.info("Job with triggerName {} triggerGroup {} paused succesfully", triggerName, triggerGroup);
				return true;
			} catch (SchedulerException e) {
				logger.error("Unable to pause job with triggerName {} triggerGroup {} due to error {}", triggerName, triggerGroup, e);
				return false;
			}	
		}
		return false;
	}

	/** Resume based on jobName, jobGroup
	 * or based on triggerName, triggerGroup
	 * @param jobName
	 * @param jobGroup
	 * @param triggerName
	 * @param triggerGroup
	 * @return
	 */
	public boolean resumeSchedule( String jobName,  String jobGroup,  String triggerName,  String triggerGroup) {
		if(!StringUtils.isEmpty(jobName) && !StringUtils.isEmpty(jobGroup)) {
			try {
				scheduler.resumeJob(new JobKey(jobName, jobGroup));
				logger.info("Job with jobName {} jobGroup {} resumed succesfully", jobName, jobGroup);
				return true;
			} catch (SchedulerException e) {
				logger.error("Unable to resume job with jobName {} jobGroup {} due to error {}", jobName, jobGroup, e);
			}	
		}
		if(!StringUtils.isEmpty(triggerName) && !StringUtils.isEmpty(triggerGroup)) {
			try {
				scheduler.resumeTrigger(new TriggerKey(triggerName, triggerGroup));
				logger.info("Job with triggerName {} triggerGroup {} resumed succesfully", triggerName, triggerGroup);
				return true;
			} catch (SchedulerException e) {
				logger.error("Unable to resume job with triggerName {} triggerGroup {} due to error {}", triggerName, triggerGroup, e);
			}	
		}
		return false;
	}
	/** Pause all existing schedules
	 * @return
	 */
	public boolean pauseAll() {
		try {
			scheduler.pauseAll();
			logger.info("All jobs have been paused successfully");
			return true;
		} catch (SchedulerException e) {
			logger.error("Unable to pause all jobs  due to error {}", e);
		}
		return false;
	}
	/** Resume all existing schedules
	 * @return
	 */
	public boolean resumeAll() {
		try {
			scheduler.resumeAll();
			logger.info("All jobs have been resumed successfully");
			return true;
		} catch (SchedulerException e) {
			logger.error("Unable to resume all jobs  due to error {}", e);
		}
		return false;
	}
	/** Deletes schedules based on jobName, jobGroup
	 * @param jobName
	 * @param jobGroup
	 * @return
	 */
	public boolean deleteSchedule(String jobName,  String jobGroup) {
		try {
			scheduler.deleteJob(new JobKey(jobName, jobGroup));
			logger.info("Job has been deleted successfully with jobName {} jobGroup {} ", jobName, jobGroup);
			return true;
		} catch (SchedulerException e) {
			logger.error("Unable to delete job with jobName {} jobGroup {} due to error {}", jobName, jobGroup, e);
		}
		return false;
	}
}
