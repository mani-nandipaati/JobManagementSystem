package com.casestudy.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.service.JobService;

/** Perform all schedule operations
 * @author Mani
 *
 */
@RestController
@RequestMapping("/schedule")
public class JobController {

	Logger logger = LoggerFactory.getLogger(JobController.class);
	@Autowired
	JobService jobService;

	/** Pause schedule based on jobName, JobGroup 
	 * or based on triggerName, triggerGroup
	 * @param jobName
	 * @param jobGroup
	 * @param triggerName
	 * @param triggerGroup
	 * @return
	 */
	@RequestMapping(value="/pause",method=RequestMethod.POST)
	public ResponseEntity<String> pauseSchedule(@RequestParam(required = false) String jobName, @RequestParam(required = false) String jobGroup, 
			@RequestParam(required = false) String triggerName, @RequestParam(required = false) String triggerGroup) {

		logger.info("Pausing scheduler with jobName {} jobGroup {} triggerName {} triggerGroup {}", jobName, jobGroup, triggerName, triggerGroup);
		boolean status = jobService.pauseSchedule(jobName, jobGroup, triggerName, triggerGroup);
		if(status) {
			logger.info("Pausing scheduler with jobName {} jobGroup {} triggerName {} triggerGroup {} with SUCCESS", jobName, jobGroup, triggerName, triggerGroup);
			return ResponseEntity
					.status(HttpStatus.OK).body("Scheduler paused");
		}
		else {
			logger.info("Pausing scheduler with jobName {} jobGroup {} triggerName {} triggerGroup {} with FAIL", jobName, jobGroup, triggerName, triggerGroup);
			return ResponseEntity
					.status(HttpStatus.OK).body("Scheduler is NOT paused");
		}
	}

	/** Resume schedule based on jobName, JobGroup 
	 * or based on triggerName, triggerGroup
	 * @param jobName
	 * @param jobGroup
	 * @param triggerName
	 * @param triggerGroup
	 * @return
	 */
	@RequestMapping(value="/resume",method=RequestMethod.POST)
	public ResponseEntity<String> resumeSchedule(@RequestParam(required = false) String jobName, @RequestParam(required = false) String jobGroup, 
			@RequestParam(required = false) String triggerName, @RequestParam(required = false) String triggerGroup) {

		logger.info("Resuming scheduler with jobName {} jobGroup {} triggerName {} triggerGroup {}", jobName, jobGroup, triggerName, triggerGroup);
		boolean status = jobService.resumeSchedule(jobName, jobGroup, triggerName, triggerGroup);
		if(status) {
			logger.info("Resuming scheduler with jobName {} jobGroup {} triggerName {} triggerGroup {} with SUCCESS", jobName, jobGroup, triggerName, triggerGroup);
			return ResponseEntity
					.status(HttpStatus.OK).body("Scheduler resumed");
		}
		else {
			logger.info("Resuming scheduler with jobName {} jobGroup {} triggerName {} triggerGroup {} with FAIL", jobName, jobGroup, triggerName, triggerGroup);
			return ResponseEntity
					.status(HttpStatus.OK).body("Scheduler is NOT resumed");
		}
	}

	/** Pause All existing schedules
	 * @return
	 */
	@RequestMapping(value="/pauseAll",method=RequestMethod.POST)
	public ResponseEntity<String> pauseAllSchedule() {

		logger.info("Pausing All scheduler");
		boolean status = jobService.pauseAll();
		if(status) {
			logger.info("Pausing All scheduler with SUCCESS");
			return ResponseEntity
					.status(HttpStatus.OK).body("Paused All Schedules");
		}
		else {
			logger.info("Pausing All scheduler with FAIL");
			return ResponseEntity
					.status(HttpStatus.OK).body("NO scheduler has been paused");
		}
	}

	/** Resume All existing schedules
	 * @return
	 */
	@RequestMapping(value="/resumeAll",method=RequestMethod.POST)
	public ResponseEntity<String> resumeAllSchedule() {

		logger.info("Resuming All scheduler");
		boolean status = jobService.resumeAll();
		if(status) {
			logger.info("Resuming All scheduler with SUCCESS");
			return ResponseEntity
					.status(HttpStatus.OK).body("Resumed All Schedules");
		}
		else {
			logger.info("Resuming All scheduler with FAIL");
			return ResponseEntity
					.status(HttpStatus.OK).body("NO scheduler has been resumed");
		}
	}

	/** Deletes schedule based on jobName, jobGroup
	 * @param jobName
	 * @param jobGroup
	 * @return
	 */
	@RequestMapping(value="/delete", method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteSchedule(String jobName, String jobGroup) {
		logger.info("Deleting scheduler with jobName {} jobGroup {} ", jobName, jobGroup);
		boolean status = jobService.deleteSchedule(jobName, jobGroup);
		if(status) {
			logger.info("Deleting scheduler with jobName {} jobGroup {} with SUCCESS", jobName, jobGroup);
			return ResponseEntity
					.status(HttpStatus.OK).body("Scheduler has been deleted");
		}
		else {
			logger.info("Deleting scheduler with jobName {} jobGroup {} with FAIL", jobName, jobGroup);
			return ResponseEntity
					.status(HttpStatus.OK).body("NO scheduler has been deleted");
		}
	}


	/** Load/schedule all jobs from provided path
	 * @param path
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity<String> loadJobs(@RequestParam String path) {
		logger.info("Loading jobs from path {}  initiated", path);
		boolean status = jobService.createJob(path);
		if(status) {
			logger.info("All Jobs have been loaded from path {} ", path);
			return ResponseEntity
					.status(HttpStatus.OK).body("All Jobs have been created");
		}
		else {
			logger.info("Failure in loading job from path {} ", path);
			return ResponseEntity
					.status(HttpStatus.OK).body("Failure in job creation");
		}
	}

}
