package com.casestudy.config;

import static org.quartz.CronScheduleBuilder.cronSchedule;

import java.util.TimeZone;

import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.ObjectAlreadyExistsException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.casestudy.job.CustomQuartzJob;


/** Scheduler configuration to create job details,
 * trigger details and schedules
 * @author Mani
 *
 */
@Configuration
@EnableBatchProcessing
public class SchedulerConfig {

	Logger logger = LoggerFactory.getLogger(SchedulerConfig.class);

	@Autowired
	private Scheduler scheduler;

	@Bean
	public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
		JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
		jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
		loadJobs();
		return jobRegistryBeanPostProcessor;
	}

	/** Schedules job with job details and trigger details 
	 * if job does not exits already
	 * @param job
	 * @param trigger
	 * @throws SchedulerException
	 */
	private void scheduleJobWithTriggerIfNotPresent(JobDetail job, Trigger trigger) throws SchedulerException
	{
		if (!scheduler.checkExists(job.getKey()) && !scheduler.checkExists(trigger.getKey()))
		{
			try
			{
				logger.info("Scheduling job with Job {} Trigger {}", job, trigger);
				scheduler.scheduleJob(job, trigger);
			} catch (ObjectAlreadyExistsException existsExc)
			{
				logger.error("Job already exists with job key {} and trigger key {}", job.getKey(), trigger.getKey());
			}
		}
	}

	/** Loads all the jobs to get it triggered
	 * 
	 */
	public void loadJobs() {
		logger.info("loading all jobs");
		JobDetail jobDetail = jobDetail();
		Trigger jobTrigger = jobTrigger(jobDetail);
		try {
			scheduleJobWithTriggerIfNotPresent(jobDetail, jobTrigger);
		} catch (SchedulerException e) {
			logger.error("Unable to schedule with job key {} and trigger key {} due to error {}", jobDetail.getKey(), jobTrigger.getKey(), e );
		}
	}
	/** Creates job details using jobDataMap to schedule
	 * @return jobDetail
	 */
	public JobDetail jobDetail() {
		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put("jobName", "readCSVFileJob");
		return JobBuilder.newJob(CustomQuartzJob.class)
				.withIdentity("readCSVFileJob")
				.setJobData(jobDataMap)
				.requestRecovery(true)
				.storeDurably()
				.build();
	}

	/** Creates job trigger using jobDetail & cron expression to schedule
	 * @param jobDetail
	 * @return
	 */
	public Trigger jobTrigger(JobDetail jobDetail)
	{
		return TriggerBuilder
				.newTrigger()
				.forJob(jobDetail)
				.withIdentity("jobOneTrigger")
				.withSchedule(cronSchedule("0 0/2 * * * ?").inTimeZone(TimeZone.getTimeZone("UTC"))
						.withMisfireHandlingInstructionFireAndProceed())
				.build();
	}
}
