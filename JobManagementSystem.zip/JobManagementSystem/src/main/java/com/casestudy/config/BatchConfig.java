package com.casestudy.config;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import com.casestudy.model.Employee;


/** Configuratin file for Batch Job
 * @author Mani
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfig {
	
	Logger logger = LoggerFactory.getLogger(BatchConfig.class);
	
    @Value("${filePath:input/inputData.csv}")
    private Resource inputResource;
    
    @Autowired
    DataSource dataSource;
 
    
    /** creates a job using provided steps
     * @param jobBuilderFactory
     * @param stepBuilderFactory
     * @param dataSource
     * @return job
     */
    @Bean
    public Job readCSVFileJob(@Autowired JobBuilderFactory jobBuilderFactory, 
    		@Autowired StepBuilderFactory stepBuilderFactory, @Autowired DataSource dataSource) {
    	logger.info("logger statement....");
        return jobBuilderFactory
                .get("readCSVFileJob")
                .incrementer(new RunIdIncrementer())
                .start(step(stepBuilderFactory, dataSource))
                .build();
    }
 
    /** creates a step using reader, processor and writer
     * @param stepBuilderFactory
     * @param dataSource
     * @return step
     */
    @Bean
    public Step step(StepBuilderFactory stepBuilderFactory, DataSource dataSource) {
        return stepBuilderFactory
                .get("step")
                .<Employee, Employee>chunk(5)
                .reader(reader())
                .processor(processor())
                .writer(writer(dataSource))
                .build();
    }
     
    /** Process object from reader and gives input to writer
     * @return itemProcessor
     */
    @Bean
    public ItemProcessor<Employee, Employee> processor() {
        return new DBLogProcessor();
    }
     
    /** Creates FileItemReader to read data from input resource
     * @return ItemReader
     */
    @Bean
    public FlatFileItemReader<Employee> reader() {
        FlatFileItemReader<Employee> itemReader = new FlatFileItemReader<>();
        itemReader.setLineMapper(lineMapper());
        itemReader.setLinesToSkip(1);
        itemReader.setResource(inputResource);
        return itemReader;
    }
 
    /** Reads each line of data from file and sets into mapper
     * @return LineMapper
     */
    @Bean
    public LineMapper<Employee> lineMapper() {
        DefaultLineMapper<Employee> lineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setNames("id", "firstName", "lastName");
        lineTokenizer.setIncludedFields(0, 1, 2 );
        BeanWrapperFieldSetMapper<Employee> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(Employee.class);
        lineMapper.setLineTokenizer(lineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);
        return lineMapper;
    }
 
    /** Creates ItemWriter to write data into database using dataSource
     * @param dataSource
     * @return
     */
    @Bean
    public JdbcBatchItemWriter<Employee> writer(DataSource dataSource) {
        JdbcBatchItemWriter<Employee> itemWriter = new JdbcBatchItemWriter<>();
        itemWriter.setDataSource(dataSource);
        itemWriter.setSql("INSERT INTO EMPLOYEE (ID, FIRST_NAME, LAST_NAME) VALUES (:id, :firstName, :lastName)");
        itemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Employee>());
        return itemWriter;
    }     
}