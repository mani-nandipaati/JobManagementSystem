package com.casestudy.config;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.casestudy.model.Employee;
 
/** Process records from Reader and 
 * gives input to writer
 * @author Mani
 *
 */
public class DBLogProcessor implements ItemProcessor<Employee, Employee>
{
	Logger logger = LoggerFactory.getLogger(DBLogProcessor.class);
	
    public Employee process(Employee employee) throws Exception
    {
        logger.info("Inserting employee : {} ",  employee);
        return employee;
    }
}