package com.casestudy.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.casestudy.schedule.RecurringType;
import com.casestudy.schedule.ScheduleDetail;

/** For Recurring Schedules
 * @author Mani
 *
 */
public class RecurringCronBuilder implements ScheduleCronBuilder{
	Logger logger = LoggerFactory.getLogger(RecurringCronBuilder.class);
	@Override
	public String getExpression(ScheduleDetail scheduleDetail) {
		String cronExpression="";//0 0/7 * 1/1 * ? *  	0 0 0/7 1/1 * ? *  0 3 9 1/1 * ? *
		if(scheduleDetail.getRecurringType() == RecurringType.MINUTES) {
			cronExpression = "0 0/"+scheduleDetail.getRecurringInterval()+" * 1/1 * ? *";
		}
		else if(scheduleDetail.getRecurringType() == RecurringType.HOURLY) {
			if(scheduleDetail.getRecurringInterval() > 0 ) {
				cronExpression = "0 0 0/"+scheduleDetail.getRecurringInterval()+" 1/1 * ? *";
			}
			else {
				cronExpression = "0 "+scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() +" 1/1 * ? *";
			}
		}
		logger.info("Cron expression {} retrieved from RECURRING scheduler for ScheduleDetail {} ", cronExpression, scheduleDetail);
		return cronExpression;
	}

}
