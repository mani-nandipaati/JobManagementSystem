package com.casestudy.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.casestudy.schedule.ScheduleDetail;

/** For Yearly Schedules
 * @author Mani
 *
 */
public class YearlyScheduleCronBuilder implements ScheduleCronBuilder {

	Logger logger = LoggerFactory.getLogger(YearlyScheduleCronBuilder.class);
	
	@Override
	public String getExpression(ScheduleDetail scheduleDetail) {
		String cronExpression = "";//0 10 16 5 3 ? *
		if(scheduleDetail.getMonthOfYear() != null  && scheduleDetail.getDayOfMonth() > 0) {
			int monthOfYear = scheduleDetail.getMonthOfYear().ordinal()+1;
			cronExpression =  "0 "+ scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() + " "+
					scheduleDetail.getDayOfMonth() +"  "+ monthOfYear +" ? *";
		}
		else {
			int weekOfMonth = scheduleDetail.getWeekOfMonth().ordinal()+1;
			int monthOfYear = scheduleDetail.getMonthOfYear().ordinal()+1;
			cronExpression =  "0 "+ scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() + " ? "+
					monthOfYear +" "+ scheduleDetail.getWeekDay() +"#"+weekOfMonth +" *";
		}
		logger.info("Cron expression {} retrieved from YEARLY scheduler for ScheduleDetail {} ", cronExpression, scheduleDetail);
		return cronExpression;
	}

}
