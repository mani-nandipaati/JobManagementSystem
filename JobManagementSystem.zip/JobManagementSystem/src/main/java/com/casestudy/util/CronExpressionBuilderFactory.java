package com.casestudy.util;

import com.casestudy.schedule.ScheduleType;

/** Factory class for CronExpression
 * @author Mani
 *
 */
public class CronExpressionBuilderFactory {
	
	private static final CronExpressionBuilderFactory builderFactory = new CronExpressionBuilderFactory();
	
	public  static CronExpressionBuilderFactory getInstance() {
		return builderFactory;
	}
	
	/** Gets respective builder based on schedule type
	 * @param scheduleType
	 * @return
	 */
	public ScheduleCronBuilder getCronBuilder(ScheduleType scheduleType) {
		switch(scheduleType) {
		case DAILY: return new DailyScheduleCronBuilder();
		case MONTHLY: return new MonthlyScheduleCronBuilder();
		case WEEKLY: return new WeeklyScheduleCronBuilder();
		case YEARLY: return new YearlyScheduleCronBuilder();
		default: return new RecurringCronBuilder();
		}
	}
}
