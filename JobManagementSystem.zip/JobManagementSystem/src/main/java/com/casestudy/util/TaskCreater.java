package com.casestudy.util;

import static org.quartz.CronScheduleBuilder.cronSchedule;

import java.util.TimeZone;

import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.ObjectAlreadyExistsException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.DuplicateJobException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.support.ReferenceJobFactory;
import org.springframework.batch.core.step.tasklet.MethodInvokingTaskletAdapter;
import org.springframework.batch.core.step.tasklet.Tasklet;

import com.casestudy.job.CustomQuartzJob;

/** Utility class for creating/scheduling external batch job
 * @author Mani
 *
 */
public class TaskCreater {
	
	private TaskCreater() {
		
	}

	private static Logger logger = LoggerFactory.getLogger(TaskCreater.class);
	
	/** Creates Tasklet based on external class name and method name
	 * @param className
	 * @param methodName
	 * @return
	 */
	public static MethodInvokingTaskletAdapter methodInvokingTaskletAdapter(String className, String methodName) {
		MethodInvokingTaskletAdapter methodInvokingTaskletAdapter = new MethodInvokingTaskletAdapter();
		methodInvokingTaskletAdapter.setTargetMethod(methodName);
		methodInvokingTaskletAdapter.setTargetObject(createObject(className));
		return methodInvokingTaskletAdapter;
	}

	/** creates instance for external class name
	 * @param className
	 * @return
	 */
	public static Object createObject(String className) {
		Object object = null;
		try {
			object = Class.forName(className).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			logger.error("Error loading class {} due to error {}", className, e);
		}
		return object;
	}
	/** creates step based on external task
	 * @param steps
	 * @param tasklet
	 * @param stepName
	 * @return
	 */
	public static Step createStep(StepBuilderFactory steps, Tasklet tasklet, String stepName) {
		return steps.get(stepName)
				.tasklet(tasklet)
				.build();
	}
	/** Creates Job based on job name
	 * and registers job with job registry
	 * @param jobs
	 * @param step
	 * @param jobName
	 * @param jobRegistry
	 * @return
	 */
	public static Job createJob(JobBuilderFactory jobs, Step step, String jobName, JobRegistry jobRegistry) {
		Job job = jobs.get(jobName)
				.flow(step)
				.build()
				.build();
		try {
			jobRegistry.register(new ReferenceJobFactory(job));
		} catch (DuplicateJobException e) {
			logger.error("Error loading job {} into job registry due to an error", job, e);
		}

		return job;
	}

	/** Creates jobDetail with job name and job group 
	 * @param jobName
	 * @param jobGroup
	 * @return
	 */
	public static JobDetail createJobDetail(String jobName, String jobGroup) {

		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put("jobName", jobName);
		return JobBuilder.newJob(CustomQuartzJob.class)
				.withIdentity(jobName, jobGroup)
				.setJobData(jobDataMap)
				.requestRecovery(true)
				.storeDurably()
				.build();
	}

	/** creates trigger with job detail, cron expression, trigger name and group
	 * @param jobDetail
	 * @param triggerName
	 * @param triggerGroup
	 * @param cronExpression
	 * @param priority
	 * @return
	 */
	public static Trigger createJobTrigger(JobDetail jobDetail, String triggerName, String triggerGroup, String cronExpression,int priority)
	{
		return TriggerBuilder
				.newTrigger()
				.forJob(jobDetail)
				.withIdentity(triggerName, triggerGroup)
				.withPriority(priority)
				.withSchedule(cronSchedule(cronExpression).inTimeZone(TimeZone.getTimeZone("UTC"))
						.withMisfireHandlingInstructionFireAndProceed())
				.build();
	}

	/** Schedules  with job details and trigger 
	 * if job not exists
	 * @param scheduler
	 * @param jobDetail
	 * @param trigger
	 * @throws SchedulerException
	 */
	public static void scheduleJobWithTriggerIfNotPresent(Scheduler scheduler, JobDetail jobDetail, Trigger trigger) throws SchedulerException
	{
		if (!scheduler.checkExists(jobDetail.getKey()) && !scheduler.checkExists(trigger.getKey()))
		{
			try
			{
				logger.info("Scheduling job with Job {} Trigger {}", jobDetail, trigger);
				scheduler.scheduleJob(jobDetail, trigger);
			} catch (ObjectAlreadyExistsException existsExc)
			{
				logger.error("Job already exists with job key {} and trigger key {}", jobDetail.getKey(), trigger.getKey());
			}
		}
	}


}
