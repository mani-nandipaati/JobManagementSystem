package com.casestudy.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.casestudy.schedule.ScheduleDetail;

/** For Daily Schedules
 * @author Mani
 *
 */
public class DailyScheduleCronBuilder implements ScheduleCronBuilder {

	Logger logger = LoggerFactory.getLogger(DailyScheduleCronBuilder.class);
	@Override
	public String getExpression(ScheduleDetail scheduleDetail) {
		String cronExpression="";//0 8 4 ? * MON-FRI *  0 8 4 1/1 * ? *
		if(scheduleDetail.isWeekDay()) {
			cronExpression = "0 "+ scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() + " ? * MON-FRI *";
		}
		else {
			cronExpression = "0 "+ scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() + " 1/" +
						scheduleDetail.getRecurringDays()+" * ? *";
		}
		logger.info("Cron expression {} retrieved from DAILY scheduler for ScheduleDetail {} ", cronExpression, scheduleDetail);
		return cronExpression;
	}

}
