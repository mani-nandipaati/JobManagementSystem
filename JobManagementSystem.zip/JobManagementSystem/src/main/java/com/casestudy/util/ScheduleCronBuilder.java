package com.casestudy.util;

import com.casestudy.schedule.ScheduleDetail;

public interface ScheduleCronBuilder {

	/** Gets cron expression based on schedule detail
	 * @param scheduleDetail
	 * @return
	 */
	String getExpression(ScheduleDetail scheduleDetail);
}
