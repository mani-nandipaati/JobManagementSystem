package com.casestudy.util;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.casestudy.schedule.ScheduleDetail;

/** For Weekly Schedules
 * @author Mani
 *
 */
public class WeeklyScheduleCronBuilder implements ScheduleCronBuilder {

	Logger logger = LoggerFactory.getLogger(WeeklyScheduleCronBuilder.class);
	
	@Override
	public String getExpression(ScheduleDetail scheduleDetail) {
		//0 6 4 ? * TUE,SAT,SUN *
		String newString = Arrays.toString(scheduleDetail.getWeekDays());
	    newString = newString.substring(1, newString.length()-1);           
	    newString = newString.replaceAll(" ", ""); 
	    String cronExpression =  "0 "+ scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() + " ? * "+ newString +" *";
	    logger.info("Cron expression {} retrieved from WEEKLY scheduler for ScheduleDetail {} ", cronExpression, scheduleDetail);
		return cronExpression;
	}

}
