package com.casestudy.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.casestudy.schedule.ScheduleDetail;

/** For Monthly Schedules
 * @author Mani
 *
 */
public class MonthlyScheduleCronBuilder implements ScheduleCronBuilder {

	Logger logger = LoggerFactory.getLogger(DailyScheduleCronBuilder.class);
	
	@Override
	public String getExpression(ScheduleDetail scheduleDetail) {
		String cronExpression="";//0 6 15 20 1/4 ? *  0 6 15 ? 1/5 WED#3 *
		
		if(scheduleDetail.getDayOfMonth() > 0 && scheduleDetail.getRecurringMonthOfYear() > 0) {
			cronExpression =  "0 "+ scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() + " "+
					scheduleDetail.getDayOfMonth() +" 1/"+ scheduleDetail.getRecurringMonthOfYear() +" ? *";
		}
		else {
			int weekOfMonth = scheduleDetail.getWeekOfMonth().ordinal()+1;
			cronExpression =  "0 "+ scheduleDetail.getRunMinute() +" "+ scheduleDetail.getRunHour() + " ? 1/"+
					scheduleDetail.getRecurringMonthOfYear() +" "+ scheduleDetail.getWeekDay().toString() +"#"+weekOfMonth
					 +" *";
		}
		logger.info("Cron expression {} retrieved from MONTHLY scheduler for ScheduleDetail {} ", cronExpression, scheduleDetail);
		return cronExpression;
	}

}
